prompt --application/shared_components/navigation/breadcrumbs/breadcrumb
begin
--   Manifest
--     MENU: Breadcrumb
--   Manifest End
wwv_flow_api.component_begin (
 p_version_yyyy_mm_dd=>'2020.03.31'
,p_release=>'20.1.0.00.13'
,p_default_workspace_id=>13936583163386839367
,p_default_application_id=>114530
,p_default_id_offset=>0
,p_default_owner=>'ALPHALOANPRO'
);
wwv_flow_api.create_menu(
 p_id=>wwv_flow_api.id(13945524771963678741)
,p_name=>'Breadcrumb'
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(13945524911717678742)
,p_short_name=>'Home'
,p_link=>'f?p=&APP_ID.:1:&APP_SESSION.::&DEBUG.'
,p_page_id=>1
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(13945719013168678980)
,p_short_name=>'Administration'
,p_link=>'f?p=&APP_ID.:10000:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10000
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(13946172304843213125)
,p_parent_id=>wwv_flow_api.id(13945524911717678742)
,p_short_name=>'MisCreditos'
,p_link=>'f?p=&APP_ID.:3:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>3
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(13961269537250478382)
,p_short_name=>'GRIDS INTERACTIVOS'
,p_link=>'f?p=&APP_ID.:5:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>5
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(13962401826923490241)
,p_parent_id=>wwv_flow_api.id(13961269537250478382)
,p_short_name=>'IG PRESTATARIO'
,p_link=>'f?p=&APP_ID.:6:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>6
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(13965934764699063083)
,p_parent_id=>wwv_flow_api.id(13961269537250478382)
,p_short_name=>'IG ABONO'
,p_link=>'f?p=&APP_ID.:7:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>7
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(13967791544637076508)
,p_parent_id=>wwv_flow_api.id(13961269537250478382)
,p_short_name=>'IG SOLICITUD DE PRESTAMO'
,p_link=>'f?p=&APP_ID.:8:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>8
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(13969068564670586942)
,p_parent_id=>wwv_flow_api.id(13961269537250478382)
,p_short_name=>'IG PRESTAMISTA'
,p_link=>'f?p=&APP_ID.:9:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>9
);
wwv_flow_api.create_menu_option(
 p_id=>wwv_flow_api.id(13969385488733639277)
,p_parent_id=>wwv_flow_api.id(13961269537250478382)
,p_short_name=>'IG PRESTAMO'
,p_link=>'f?p=&APP_ID.:10:&APP_SESSION.::&DEBUG.:::'
,p_page_id=>10
);
wwv_flow_api.component_end;
end;
/
